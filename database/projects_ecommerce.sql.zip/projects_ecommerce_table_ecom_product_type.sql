
-- --------------------------------------------------------

--
-- Table structure for table `ecom_product_type`
--

CREATE TABLE `ecom_product_type` (
  `id` int(11) NOT NULL,
  `reg_id` varchar(50) NOT NULL,
  `product_name` varchar(350) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
