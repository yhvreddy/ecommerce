
-- --------------------------------------------------------

--
-- Table structure for table `ecom_forget_password`
--

CREATE TABLE `ecom_forget_password` (
  `id` int(11) NOT NULL,
  `mail_id` varchar(250) NOT NULL,
  `reset_token` text NOT NULL,
  `verify_code` varchar(10) NOT NULL DEFAULT 'NULL',
  `status` int(11) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
