
-- --------------------------------------------------------

--
-- Table structure for table `ecom_tags`
--

CREATE TABLE `ecom_tags` (
  `id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='tags like :Brands, etc';
