
-- --------------------------------------------------------

--
-- Table structure for table `ecom_categories`
--

CREATE TABLE `ecom_categories` (
  `id` int(11) NOT NULL,
  `reg_id` varchar(50) NOT NULL,
  `category_name` varchar(150) NOT NULL,
  `image` varchar(350) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='storing categories Ex: Electronics, TVs & Appliances, Men, Women, Books, etc..';
