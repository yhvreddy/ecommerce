
-- --------------------------------------------------------

--
-- Table structure for table `ecom_merchants`
--

CREATE TABLE `ecom_merchants` (
  `id` int(11) NOT NULL,
  `reg_id` varchar(25) DEFAULT NULL,
  `first_name` varchar(350) NOT NULL,
  `last_name` varchar(250) DEFAULT NULL,
  `mobile` bigint(20) NOT NULL,
  `mail_id` varchar(350) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `pincode` int(11) NOT NULL,
  `otp` int(6) NOT NULL,
  `otp_status` int(5) NOT NULL DEFAULT 0 COMMENT '0-No, 1-Yes',
  `status` int(5) NOT NULL DEFAULT 0,
  `password` varchar(300) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Add Merchants to manage accounts';
