
-- --------------------------------------------------------

--
-- Table structure for table `ecom_users_types`
--

CREATE TABLE `ecom_users_types` (
  `id` int(11) NOT NULL,
  `name` varchar(350) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1-superadmin, 2-admin, 3-employees',
  `status` int(11) NOT NULL DEFAULT 1,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_users_types`
--

INSERT INTO `ecom_users_types` (`id`, `name`, `type`, `status`, `created`) VALUES
(1, 'superadmin', 1, 1, '2019-10-18 18:36:07'),
(2, 'admin', 2, 1, '2019-10-18 18:36:07'),
(3, 'employees', 3, 1, '2019-10-18 18:36:07');
