
-- --------------------------------------------------------

--
-- Table structure for table `ecom_site_details`
--

CREATE TABLE `ecom_site_details` (
  `id` int(11) NOT NULL,
  `reg_id` varchar(50) NOT NULL,
  `site_name` varchar(280) NOT NULL,
  `website` varchar(280) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `phone` int(11) NOT NULL,
  `mail_id` varchar(250) NOT NULL,
  `alter_mail_id` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `fav_icon` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
