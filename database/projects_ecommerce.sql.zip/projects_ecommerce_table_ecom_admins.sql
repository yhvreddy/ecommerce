
-- --------------------------------------------------------

--
-- Table structure for table `ecom_admins`
--

CREATE TABLE `ecom_admins` (
  `id` int(11) NOT NULL,
  `name` varchar(350) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `mail_id` varchar(350) NOT NULL,
  `type` int(11) NOT NULL,
  `password` text NOT NULL,
  `otp` int(11) DEFAULT NULL,
  `otp_status` int(11) DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecom_admins`
--

INSERT INTO `ecom_admins` (`id`, `name`, `mobile`, `mail_id`, `type`, `password`, `otp`, `otp_status`, `status`, `created`, `updated`) VALUES
(1, 'Harshavadrhan Reddy', 9865432100, 'admin@gmail.com', 1, '$2y$10$INVKC4U5XJr.9AMFTPL0m.H4v2xd2KRHuZim5dyprzbZ/4s9CzhBe', NULL, 0, 1, '2020-02-10 09:20:39', '2020-02-11 02:26:17');
