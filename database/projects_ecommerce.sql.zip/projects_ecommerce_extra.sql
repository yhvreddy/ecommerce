
--
-- Indexes for dumped tables
--

--
-- Indexes for table `ecom_admins`
--
ALTER TABLE `ecom_admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `mail_id` (`mail_id`);

--
-- Indexes for table `ecom_banners`
--
ALTER TABLE `ecom_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_categories`
--
ALTER TABLE `ecom_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_forget_password`
--
ALTER TABLE `ecom_forget_password`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `verify_token` (`reset_token`) USING HASH;

--
-- Indexes for table `ecom_merchants`
--
ALTER TABLE `ecom_merchants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail_id` (`mail_id`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `reg_id` (`reg_id`);

--
-- Indexes for table `ecom_products`
--
ALTER TABLE `ecom_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_product_type`
--
ALTER TABLE `ecom_product_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_site_details`
--
ALTER TABLE `ecom_site_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg_id` (`reg_id`);

--
-- Indexes for table `ecom_sub_categories`
--
ALTER TABLE `ecom_sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecom_tags`
--
ALTER TABLE `ecom_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg_id` (`reg_id`);

--
-- Indexes for table `ecom_users`
--
ALTER TABLE `ecom_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail_id` (`mail_id`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `reg_id` (`reg_id`);

--
-- Indexes for table `ecom_users_types`
--
ALTER TABLE `ecom_users_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ecom_admins`
--
ALTER TABLE `ecom_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ecom_banners`
--
ALTER TABLE `ecom_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_categories`
--
ALTER TABLE `ecom_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_forget_password`
--
ALTER TABLE `ecom_forget_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_merchants`
--
ALTER TABLE `ecom_merchants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_products`
--
ALTER TABLE `ecom_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_product_type`
--
ALTER TABLE `ecom_product_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_site_details`
--
ALTER TABLE `ecom_site_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_sub_categories`
--
ALTER TABLE `ecom_sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_tags`
--
ALTER TABLE `ecom_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_users`
--
ALTER TABLE `ecom_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecom_users_types`
--
ALTER TABLE `ecom_users_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
