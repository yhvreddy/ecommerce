
-- --------------------------------------------------------

--
-- Table structure for table `ecom_sub_categories`
--

CREATE TABLE `ecom_sub_categories` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_name` varchar(350) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `reg_id` varchar(50) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
